<template>
  <div class="modal-footer enhanced-footer compact">
    <button type="button" @click="$emit('cancel')" 
            class="btn btn-secondary compact" :disabled="isDisabled">
      <i class="fas fa-times"></i> ຍົກເລີກ
    </button>
    <button type="button" @click="$emit('save')" 
            class="btn btn-primary compact" 
            :disabled="isDisabled || !isFormValid">
      <i v-if="isSubmitting" class="fas fa-spinner fa-spin"></i>
      <i v-else :class="isEditMode ? 'fa-save' : 'fa-plus'" class="fas"></i>
      {{ isSubmitting ? 'ກຳລັງບັນທຶກ...' : isEditMode ? 'ອັບເດດ' : 'ບັນທຶກ' }}
    </button>
    <button type="button" @click="$emit('print')" 
            class="btn btn-sm btn-outline-secondary"
            :disabled="isDisabled || !isFormValid">
      <i class="fas fa-print"></i> Save & Print
    </button>
  </div>
</template>
