<template>
  <div>
    <div v-if="visible" class="modal-overlay" @click="handleOverlayClick">
      <div class="modal-dialog enhanced-dialog" @click.stop>
        <!-- Header Component -->
        <SettlementHeader
          :is-edit-mode="isEditMode"
          :voucher-number="formattedVoucherNumber"
          :is-disabled="isFormDisabled"
          @close="closeDialog"
        />

        <!-- Form Component -->
        <SettlementForm
          ref="settlementForm"
          :settlement="currentSettlement"
          :currencies="currencies"
          :bank-accounts="bankAccounts"
          :ministries="ministries"
          :chart-accounts="chartAccounts"
          :users="users"
          :payment-method="paymentMethod"
          :is-submitting="isSubmitting"
          :is-edit-mode="isEditMode"
          @update:formData="handleFormDataUpdate"
          @validation-change="handleValidationChange"
        />

        <!-- Footer Component -->
        <SettlementFooter
          :is-edit-mode="isEditMode"
          :is-submitting="isSubmitting"
          :is-form-valid="isFormValid"
          :is-disabled="isFormDisabled"
          @cancel="closeDialog"
          @save="saveSettlement"
          @print="printSettlement"
        />
      </div>
    </div>

    <!-- Print Component -->
    <VoucherPrintComponent
      v-if="showPrintVoucher && settlementDetail"
      :key="settlementDetail.id"
      :voucher-data="settlementDetail"
      @close="closePrintVoucher"
    />
  </div>
</template>

<script>
// Import child components
import SettlementHeader from './SettlementHeader.vue'
import SettlementForm from '../settlement/SettlementForm'
import SettlementFooter from '../settlement/settlementFooter'
import VoucherPrintComponent from '~/components/MA/settlementVoucher'

// Import composables
import { useSettlementValidation } from '~/composables/useSettlementValidation'

export default {
  name: 'SettlementDialog',

  components: {
    SettlementHeader,
    SettlementForm,
    SettlementFooter,
    VoucherPrintComponent
  },

  props: {
    paymentMethod: {
      type: String,
      default: 'cash'
    },
    visible: {
      type: Boolean,
      default: false
    },
    settlement: {
      type: Object,
      default: null
    },
    currencies: {
      type: Array,
      default: () => []
    },
    bankAccounts: {
      type: Array,
      default: () => []
    },
    ministries: {
      type: Array,
      default: () => []
    },
    chartAccounts: {
      type: Array,
      default: () => []
    },
    users: {
      type: Array,
      default: () => []
    }
  },

  emits: ['close', 'save', 'created', 'updated'],

  data() {
    return {
      isSubmitting: false,
      showPrintVoucher: false,
      settlementDetail: null,
      currentSettlement: null,
      formData: {},
      isFormValid: false,
      justCreated: false,
      validationErrors: {}
    }
  },

  computed: {
    isEditMode() {
      return !!(this.currentSettlement?.id || (this.formData.id && this.justCreated))
    },

    isFormDisabled() {
      return this.isSubmitting
    },

    formattedVoucherNumber() {
      const id = this.currentSettlement?.id || this.formData.id
      return id ? String(id).padStart(6, '0') : '000000'
    }
  },

  watch: {
    visible(newVal) {
      if (newVal) {
        this.justCreated = false
        this.currentSettlement = this.settlement
        this.$nextTick(() => {
          this.initializeForm()
        })
      } else {
        this.resetDialog()
      }
    },

    settlement: {
      handler(newVal) {
        if (this.visible && !this.isSubmitting && !this.justCreated) {
          this.currentSettlement = newVal
          this.$nextTick(() => {
            this.initializeForm()
          })
        }
      },
      deep: true
    }
  },

  mounted() {
    // Initialize validation composable
    const { checkFormReadiness } = useSettlementValidation()
    this.checkFormReadiness = checkFormReadiness
  },

  beforeDestroy() {
    this.cleanup()
  },

  methods: {
    initializeForm() {
      if (this.$refs.settlementForm) {
        this.$refs.settlementForm.initializeForm()
      }
    },

    handleFormDataUpdate(data) {
      this.formData = { ...data }
      this.validateCurrentForm()
    },

    handleValidationChange({ isValid, errors }) {
      this.isFormValid = isValid
      this.validationErrors = errors
    },

    validateCurrentForm() {
      if (this.checkFormReadiness) {
        const { isReady } = this.checkFormReadiness(
          this.formData,
          this.users,
          this.currencies
        )
        this.isFormValid = isReady
      }
    },

    async saveSettlement() {
      if (!this.isFormValid || this.isSubmitting) {
        return
      }

      this.isSubmitting = true

      try {
        const submitData = this.prepareSubmitData()
        let response

        if (this.isEditMode) {
          response = await this.$axios.put(
            `/api/settlements/${this.formData.id}`,
            submitData
          )
          this.$emit('updated', response.data.data)
          this.showToast('Money settlement updated successfully', 'success')
        } else {
          response = await this.$axios.post('/api/settlements', submitData)
          
          if (response.data?.data) {
            this.formData.id = response.data.data.id
            this.currentSettlement = response.data.data
            this.justCreated = true
            this.$emit('created', response.data.data)
            this.showToast('Money settlement created successfully', 'success')
          }
        }
      } catch (error) {
        this.handleSubmitError(error)
      } finally {
        this.isSubmitting = false
      }
    },

    prepareSubmitData() {
      const submitData = { ...this.formData }

      // Remove empty values
      Object.keys(submitData).forEach(key => {
        if (submitData[key] === '' || submitData[key] === null) {
          delete submitData[key]
        }
      })

      // Handle advance linking
      if (submitData.linkToAdvance !== 'true') {
        delete submitData.moneyAdvanceId
      }
      delete submitData.linkToAdvance

      return submitData
    },

    handleSubmitError(error) {
      let errorMessage = 'ເກີດຂໍ້ຜິດພາດໃນການບັນທຶກ'

      if (error.response) {
        const status = error.response.status
        const errorData = error.response.data

        if (status === 422 && errorData.errors) {
          // Validation errors
          const firstError = Object.values(errorData.errors)[0][0]
          errorMessage = firstError
        } else if (status === 409) {
          errorMessage = 'ມີການຂັດແຍ້ງກັບຂໍ້ມູນທີ່ມີຢູ່ແລ້ວ'
        } else if (status === 404) {
          errorMessage = 'ບໍ່ພົບຂໍ້ມູນທີ່ຕ້ອງການ'
        } else {
          errorMessage = errorData.message || errorMessage
        }
      } else if (error.request) {
        errorMessage = 'ບໍ່ສາມາດເຊື່ອມຕໍ່ເຊີເວີໄດ້'
      }

      this.showToast(errorMessage, 'error')
    },

    async printSettlement() {
      await this.saveSettlement()
      
      if (this.formData.id) {
        await this.fetchSettlementDetail()
        this.showPrintVoucher = true
      }
    },

    async fetchSettlementDetail() {
      if (!this.formData.id) {
        this.showToast('ກະລຸນາບັນທຶກຂໍ້ມູນກ່ອນ', 'error')
        return
      }

      try {
        const { data } = await this.$axios.get(
          `/api/settlements/${this.formData.id}`
        )
        this.settlementDetail = data.data
      } catch (error) {
        this.showToast('Error fetching settlement details', 'error')
        console.error(error)
      }
    },

    closePrintVoucher() {
      this.showPrintVoucher = false
      setTimeout(() => {
        this.settlementDetail = null
      }, 100)
    },

    closeDialog() {
      if (this.isSubmitting) {
        const confirmed = confirm(
          'Are you sure you want to cancel? The form is currently being submitted.'
        )
        if (!confirmed) return
      }

      this.justCreated = false
      this.$emit('close')
    },

    handleOverlayClick(event) {
      if (event.target === event.currentTarget && !this.isSubmitting) {
        this.closeDialog()
      }
    },

    resetDialog() {
      this.isSubmitting = false
      this.showPrintVoucher = false
      this.settlementDetail = null
      this.currentSettlement = null
      this.formData = {}
      this.isFormValid = false
      this.justCreated = false
      this.validationErrors = {}
    },

    cleanup() {
      document.body.style.overflow = 'auto'
      this.resetDialog()
    },

    showToast(message, type = 'info') {
      if (this.$toast) {
        this.$toast[type](message)
      } else if (this.$notify) {
        this.$notify({
          title: type === 'error' ? 'Error' : 'Success',
          message: message,
          type: type === 'error' ? 'error' : 'success'
        })
      } else {
        console.log(`${type.toUpperCase()}: ${message}`)
      }
    }
  }
}
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
  animation: fadeIn 0.3s ease-out;
}

.enhanced-dialog {
  background: white;
  border-radius: 12px;
  max-width: 95vw;
  width: 95%;
  max-height: 95vh;
  height: 95vh;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: slideIn 0.3s ease-out;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-50px) scale(0.9);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

@media (max-width: 768px) {
  .enhanced-dialog {
    width: 98%;
    margin: 1vh auto;
    max-height: 98vh;
    height: 98vh;
  }
}
</style>