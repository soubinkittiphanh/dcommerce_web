// composables/useSettlementValidation.js

export const useSettlementValidation = () => {
  /**
   * Validate the entire settlement form
   * @param {Object} formData - The form data to validate
   * @returns {Object} - Object containing errors, formErrors array, and isValid boolean
   */
  const validateForm = (formData) => {
    const errors = {}
    const formErrors = []

    // Required fields validation
    if (!formData.bookingDate) {
      errors.bookingDate = 'ກະລຸນາເລືອກວັນທີ'
      formErrors.push('ວັນທີລົງຊຳລະ ແມ່ນຈຳເປັນ')
    }

    if (!formData.method) {
      errors.method = 'ກະລຸນາເລືອກວິທີການຊຳລະ'
      formErrors.push('ວິທີການຊຳລະ ແມ່ນຈຳເປັນ')
    }

    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      errors.amount = 'ກະລຸນາໃສ່ຈຳນວນເງິນທີ່ຖືກຕ້ອງ'
      formErrors.push('ຈຳນວນເງິນ ແມ່ນຈຳເປັນ ແລະ ຕ້ອງຫຼາຍກວ່າ 0')
    }

    if (!formData.currencyId) {
      errors.currencyId = 'ກະລຸນາເລືອກສະກຸນເງິນ'
      formErrors.push('ສະກຸນເງິນ ແມ່ນຈຳເປັນ')
    }

    if (formData.exchangeRate && parseFloat(formData.exchangeRate) <= 0) {
      errors.exchangeRate = 'ອັດຕາແລກປ່ຽນຕ້ອງຫຼາຍກວ່າ 0'
      formErrors.push('ອັດຕາແລກປ່ຽນຕ້ອງຫຼາຍກວ່າ 0')
    }

    if (!formData.userId) {
      errors.userId = 'ກະລຸນາເລືອກຜູ້ລົງບັນຊີ'
      formErrors.push('ຜູ້ລົງບັນຊີ ແມ່ນຈຳເປັນ')
    }

    // Conditional validations based on payment method
    if (formData.method === 'bank_transfer' && !formData.bankAccountId) {
      errors.bankAccountId = 'ກະລຸນາເລືອກບັນຊີທະນາຄານ'
      formErrors.push('ບັນຊີທະນາຄານ ແມ່ນຈຳເປັນສຳລັບການໂອນທະນາຄານ')
    }

    if (formData.method === 'cheque' && !formData.chequeNo) {
      errors.chequeNo = 'ກະລຸນາໃສ່ເລກເຊັກ'
      formErrors.push('ເລກເຊັກ ແມ່ນຈຳເປັນສຳລັບການຊຳລະດ້ວຍເຊັກ')
    }

    if ((formData.method === 'cash' || formData.method === 'cheque') && !formData.fromPersonName) {
      errors.fromPersonName = 'ກະລຸນາໃສ່ຊື່ຜູ້ຈ່າຍ'
      formErrors.push('ຊື່ຜູ້ຈ່າຍ ແມ່ນຈຳເປັນສຳລັບການຊຳລະດ້ວຍເງິນສົດ ແລະ ເຊັກ')
    }

    // Validate notes length
    if (formData.notes && formData.notes.length > 500) {
      errors.notes = 'ໝາຍເຫດຕ້ອງບໍ່ເກີນ 500 ຕົວອັກສອນ'
      formErrors.push('ໝາຍເຫດຕ້ອງບໍ່ເກີນ 500 ຕົວອັກສອນ')
    }

    return {
      errors,
      formErrors,
      isValid: formErrors.length === 0
    }
  }

  /**
   * Validate individual field
   * @param {String} fieldName - Name of the field to validate
   * @param {Any} value - Value of the field
   * @param {Object} formData - Complete form data for context
   * @returns {String|null} - Error message or null if valid
   */
  const validateField = (fieldName, value, formData = {}) => {
    switch (fieldName) {
      case 'bookingDate':
        return !value ? 'ກະລຸນາເລືອກວັນທີ' : null
      
      case 'method':
        return !value ? 'ກະລຸນາເລືອກວິທີການຊຳລະ' : null
      
      case 'amount':
        if (!value || value <= 0) {
          return 'ຈຳນວນເງິນຕ້ອງຫຼາຍກວ່າ 0'
        }
        return null
      
      case 'currencyId':
        return !value ? 'ກະລຸນາເລືອກສະກຸນເງິນ' : null
      
      case 'exchangeRate':
        if (value && value <= 0) {
          return 'ອັດຕາແລກປ່ຽນຕ້ອງຫຼາຍກວ່າ 0'
        }
        return null
      
      case 'bankAccountId':
        if (formData.method === 'bank_transfer' && !value) {
          return 'ກະລຸນາເລືອກບັນຊີທະນາຄານ'
        }
        return null
      
      case 'chequeNo':
        if (formData.method === 'cheque' && !value) {
          return 'ກະລຸນາໃສ່ເລກເຊັກ'
        }
        return null
      
      case 'fromPersonName':
        if ((formData.method === 'cash' || formData.method === 'cheque') && !value) {
          return 'ກະລຸນາໃສ່ຊື່ຜູ້ຈ່າຍ'
        }
        return null
      
      case 'notes':
        if (value && value.length > 500) {
          return 'ໝາຍເຫດຕ້ອງບໍ່ເກີນ 500 ຕົວອັກສອນ'
        }
        return null
      
      default:
        return null
    }
  }

  /**
   * Validate linked advance requirements
   * @param {Object} formData - Form data
   * @param {Object} selectedAdvance - Selected advance object
   * @param {Function} getAdvanceCurrency - Function to get advance currency
   * @returns {Object} - Validation result with errors
   */
  const validateAdvanceLink = (formData, selectedAdvance, getAdvanceCurrency) => {
    const errors = {}
    const formErrors = []

    if (!selectedAdvance) {
      return { errors, formErrors, isValid: true }
    }

    // Check currency match
    const advanceCurrency = getAdvanceCurrency()
    if (advanceCurrency && formData.currencyId != advanceCurrency.id) {
      errors.currencyId = 'ສະກຸນເງິນຕ້ອງກົງກັບລາຍຈ່າຍລ່ວງໜ້າ'
      formErrors.push('ສະກຸນເງິນຕ້ອງກົງກັບລາຍຈ່າຍລ່ວງໜ້າທີ່ເລືອກ')
    }

    // Check amount match
    if (selectedAdvance.amount && Math.abs(formData.amount - selectedAdvance.amount) > 0.01) {
      errors.amount = 'ຈຳນວນເງິນຕ້ອງກົງກັບລາຍຈ່າຍລ່ວງໜ້າ'
      formErrors.push('ຈຳນວນເງິນຕ້ອງກົງກັບລາຍຈ່າຍລ່ວງໜ້າທີ່ເລືອກ')
    }

    return {
      errors,
      formErrors,
      isValid: formErrors.length === 0
    }
  }

  /**
   * Check if form can be submitted
   * @param {Object} formData - Form data
   * @param {Array} users - Available users
   * @param {Array} currencies - Available currencies
   * @returns {Object} - Validation state
   */
  const checkFormReadiness = (formData, users = [], currencies = []) => {
    const validations = {
      hasAmount: !!(formData.amount && parseFloat(formData.amount) > 0),
      hasCurrency: !!formData.currencyId,
      hasUser: !!formData.userId,
      hasSettlementDate: !!formData.bookingDate,
      hasMethod: !!formData.method,
      hasUsers: users.length > 0,
      hasCurrencies: currencies.length > 0,
      bankAccountValid: formData.method !== 'bank_transfer' || !!formData.bankAccountId,
      exchangeRateValid: !formData.exchangeRate || formData.exchangeRate > 0,
      chequeNoValid: formData.method !== 'cheque' || !!formData.chequeNo,
      fromPersonNameValid: 
        (formData.method !== 'cash' && formData.method !== 'cheque') || 
        !!formData.fromPersonName
    }

    const isReady = Object.values(validations).every(v => v === true)

    return {
      isReady,
      validations,
      missingRequirements: Object.entries(validations)
        .filter(([_, valid]) => !valid)
        .map(([key]) => key)
    }
  }

  return {
    validateForm,
    validateField,
    validateAdvanceLink,
    checkFormReadiness
  }
}