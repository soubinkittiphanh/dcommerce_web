// composables/useSettlementForm.js

export const useSettlementForm = () => {
  /**
   * Initialize form data based on settlement or defaults
   */
  const initializeFormData = (settlement, paymentMethod, user) => {
    const today = new Date().toISOString().split('T')[0]
    
    if (settlement?.id || settlement?.moneyAdvanceId) {
      const hasMoneyAdvance = 
        settlement.moneyAdvanceId && 
        settlement.moneyAdvanceId !== null &&
        settlement.moneyAdvanceId !== '' &&
        settlement.moneyAdvanceId !== '0' &&
        settlement.moneyAdvanceId !== 0
      
      return {
        id: settlement.id,
        bookingDate: settlement.bookingDate ? settlement.bookingDate.split('T')[0] : today,
        method: settlement.method || '',
        amount: settlement.amount || null,
        currencyId: settlement.currencyId || '',
        exchangeRate: settlement.exchangeRate !== undefined && settlement.exchangeRate !== null 
          ? settlement.exchangeRate : 1,
        bankAccountId: settlement.bankAccountId || '',
        ministryId: settlement.ministryId || '',
        chartAccountId: settlement.chartAccountId || '',
        userId: settlement.userId || user?.id || '',
        notes: settlement.notes || '',
        selectedInvoices: [],
        linkToAdvance: hasMoneyAdvance || settlement.linkToAdvance === 'true' ? 'true' : 'false',
        moneyAdvanceId: hasMoneyAdvance ? settlement.moneyAdvanceId.toString() : '',
        externalRef: settlement.externalRef || '',
        externalRefNo: settlement.externalRefNo || '',
        chequeNo: settlement.chequeNo || '',
        fromPersonName: settlement.fromPersonName || ''
      }
    }
    
    // New settlement defaults
    return {
      bookingDate: today,
      method: paymentMethod || 'cash',
      amount: null,
      currencyId: '',
      exchangeRate: 1,
      bankAccountId: '',
      ministryId: '',
      chartAccountId: '',
      userId: user?.id || '',
      notes: '',
      selectedInvoices: [],
      linkToAdvance: 'false',
      moneyAdvanceId: '',
      externalRef: '',
      externalRefNo: '',
      chequeNo: '',
      fromPersonName: ''
    }
  }

  /**
   * Prepare form data for submission
   */
  const prepareSubmitData = (formData) => {
    const submitData = { ...formData }
    
    // Remove empty values
    Object.keys(submitData).forEach(key => {
      if (submitData[key] === '' || submitData[key] === null) {
        delete submitData[key]
      }
    })
    
    // Remove advance-related fields if not linking
    if (submitData.linkToAdvance !== 'true') {
      delete submitData.moneyAdvanceId
    }
    delete submitData.linkToAdvance
    
    // Remove invoice selection if not deduction method
    if (submitData.method !== 'deduction') {
      delete submitData.selectedInvoices
    }
    
    return submitData
  }

  /**
   * Handle payment method changes
   */
  const handleMethodChange = (formData, newMethod) => {
    const updatedData = { ...formData, method: newMethod }
    
    // Clear method-specific fields
    if (newMethod !== 'bank_transfer') {
      updatedData.bankAccountId = ''
    }
    if (newMethod !== 'deduction') {
      updatedData.selectedInvoices = []
    }
    if (newMethod !== 'cheque') {
      updatedData.chequeNo = ''
    }
    if (newMethod !== 'cash' && newMethod !== 'cheque') {
      updatedData.fromPersonName = ''
    }
    
    return updatedData
  }

  /**
   * Handle currency change
   */
  const handleCurrencyChange = (formData, currencies, isEditMode) => {
    const selectedCurrency = currencies.find(c => c.id == formData.currencyId)
    const currencyCode = selectedCurrency?.code || selectedCurrency?.currencyCode || 'LAK'
    const isBaseCurrency = currencyCode === 'LAK'
    
    const updatedData = { ...formData }
    
    if (isBaseCurrency) {
      if (!isEditMode || updatedData.exchangeRate === null || updatedData.exchangeRate === undefined) {
        updatedData.exchangeRate = 1
      }
    } else if (!isEditMode && (!updatedData.exchangeRate || updatedData.exchangeRate === 1)) {
      updatedData.exchangeRate = selectedCurrency?.rate || null
    }
    
    return updatedData
  }

  /**
   * Sync currency from selected advance
   */
  const syncCurrencyFromAdvance = (formData, selectedAdvance, currencies) => {
    if (!selectedAdvance) return formData
    
    const updatedData = { ...formData }
    
    // Find advance currency
    let advanceCurrency = null
    
    if (selectedAdvance.currencyId) {
      advanceCurrency = currencies.find(c => c.id == selectedAdvance.currencyId)
    } else if (selectedAdvance.currencyCode) {
      advanceCurrency = currencies.find(
        c => (c.code || c.currencyCode) === selectedAdvance.currencyCode
      )
    } else if (selectedAdvance.currency) {
      if (typeof selectedAdvance.currency === 'object') {
        advanceCurrency = currencies.find(c => c.id == selectedAdvance.currency.id)
      } else {
        advanceCurrency = currencies.find(
          c => (c.code || c.currencyCode) === selectedAdvance.currency
        )
      }
    }
    
    if (advanceCurrency) {
      updatedData.currencyId = advanceCurrency.id
      
      if (selectedAdvance.exchangeRate && selectedAdvance.exchangeRate !== null) {
        updatedData.exchangeRate = selectedAdvance.exchangeRate
      } else {
        const isBaseCurrency = (advanceCurrency.code || advanceCurrency.currencyCode) === 'LAK'
        if (isBaseCurrency && (updatedData.exchangeRate === null || updatedData.exchangeRate === undefined)) {
          updatedData.exchangeRate = 1
        }
      }
    }
    
    return updatedData
  }

  /**
   * Sync amount from selected advance
   */
  const syncAmountFromAdvance = (formData, selectedAdvance) => {
    if (!selectedAdvance || !selectedAdvance.amount) return formData
    
    return {
      ...formData,
      amount: selectedAdvance.amount
    }
  }

  /**
   * Filter bank accounts based on currency
   */
  const getFilteredBankAccounts = (bankAccounts, selectedCurrency) => {
    if (!selectedCurrency || !bankAccounts.length) {
      return bankAccounts.filter(account => account.isActive !== false)
    }
    
    const currencyCode = selectedCurrency.code || selectedCurrency.currencyCode
    const filtered = bankAccounts.filter(
      account => (account.currency === currencyCode || !account.currency) && 
                 account.isActive !== false
    )
    
    return filtered.length > 0 
      ? filtered 
      : bankAccounts.filter(account => account.isActive !== false)
  }

  /**
   * Calculate equivalent amount in base currency
   */
  const calculateEquivalentAmount = (amount, exchangeRate, currencyCode) => {
    const isBaseCurrency = currencyCode === 'LAK'
    
    if (isBaseCurrency || !amount || !exchangeRate || exchangeRate <= 0) {
      return null
    }
    
    return amount * exchangeRate
  }

  return {
    initializeFormData,
    prepareSubmitData,
    handleMethodChange,
    handleCurrencyChange,
    syncCurrencyFromAdvance,
    syncAmountFromAdvance,
    getFilteredBankAccounts,
    calculateEquivalentAmount
  }
}