<template>
  <div class="modal-header">
    <div class="modal-title-section">
      <i class="fas fa-money-bill-wave modal-icon"></i>
      <h5 class="modal-title">
        {{ isEditMode ? 'ແກ້ໄຂການຊຳລະ' : 'ລົງລາຍຮັບ ການຊຳລະ' }}
      </h5>
    </div>
    <div class="modal-header-right">
      <span class="voucher-number">ເລກທີ: {{ voucherNumber }}</span>
      <button @click="$emit('close')" class="close-btn" :disabled="isDisabled">
        <i class="fas fa-times"></i>
      </button>
    </div>
  </div>
</template>