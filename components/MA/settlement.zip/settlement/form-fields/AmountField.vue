<template>
  <div class="form-group">
    <label class="form-label required">
      <i class="fas fa-dollar-sign"></i>
      ຈຳນວນເງິນ
    </label>
    <div class="input-group compact">
      <input
        :value="value"
        type="number"
        step="0.01"
        min="0"
        class="form-control compact"
        :class="{ 'is-invalid': error }"
        :disabled="disabled"
        placeholder="0.00"
        required
        @input="handleInput"
        @blur="handleBlur"
      />
      <div class="input-group-append">
        <span class="input-group-text compact">
          {{ currencyCode }}
        </span>
      </div>
    </div>
    <div v-if="error" class="invalid-feedback">
      {{ error }}
    </div>
  </div>
</template>

<script>
export default {
  name: 'AmountField',
  
  props: {
    value: {
      type: [Number, String],
      default: null
    },
    currencyCode: {
      type: String,
      default: 'LAK'
    },
    error: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  
  emits: ['input', 'change'],
  
  methods: {
    handleInput(event) {
      const value = event.target.value
      const numValue = value === '' ? null : parseFloat(value)
      this.$emit('input', numValue)
    },
    
    handleBlur(event) {
      const value = event.target.value
      const numValue = value === '' ? null : parseFloat(value)
      this.$emit('change', numValue)
    }
  }
}
</script>

<style scoped>
.form-group {
  margin-bottom: 0;
}

.form-label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
  font-weight: 600;
  color: #374151;
  font-size: 12px;
}

.form-label.required::after {
  content: '*';
  color: #e74c3c;
  margin-left: 2px;
}

.form-label i {
  color: #6b7280;
  font-size: 10px;
}

.input-group.compact {
  display: flex;
  border-radius: 6px;
  overflow: hidden;
}

.form-control.compact {
  width: 100%;
  padding: 8px 12px;
  border: 2px solid #e5e7eb;
  border-radius: 6px 0 0 6px;
  border-right: none;
  font-size: 13px;
  transition: all 0.2s ease;
  background: #fafafa;
  box-sizing: border-box;
}

.form-control.compact:focus {
  outline: none;
  border-color: #667eea;
  background: white;
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
}

.form-control.compact:disabled {
  background-color: #f3f4f6;
  border-color: #d1d5db;
  color: #6b7280;
  cursor: not-allowed;
}

.form-control.is-invalid {
  border-color: #e74c3c;
}

.input-group-append {
  display: flex;
}

.input-group-text.compact {
  background: #f8f9fa;
  border: 2px solid #e5e7eb;
  border-left: none;
  border-radius: 0 6px 6px 0;
  padding: 8px 12px;
  font-weight: 600;
  color: #6b7280;
  font-size: 12px;
  display: flex;
  align-items: center;
}

.form-control.compact:focus + .input-group-append .input-group-text.compact {
  border-color: #667eea;
}

.invalid-feedback {
  display: block;
  color: #e74c3c;
  font-size: 10px;
  margin-top: 2px;
}

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
</style>