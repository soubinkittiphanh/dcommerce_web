
<template>
  <div class="form-group full-width">
    <label class="form-label">
      <i class="fas fa-sticky-note"></i>
      ເນື້ອໃນລາຍຮັບ (ໝາຍເຫດ)
    </label>
    <textarea
      :value="value"
      class="form-control compact"
      :disabled="disabled"
      rows="3"
      placeholder="ເນື້ອໃນລາຍຮັບ / ລາຍລະອຽດເພີ່ມເຕີມ..."
      maxlength="500"
      @input="handleInput"
    ></textarea>
    <div class="field-hint">
      <span class="text-counter">{{ charCount }}/500</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'NotesField',
  
  props: {
    value: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  
  emits: ['input'],
  
  computed: {
    charCount() {
      return this.value?.length || 0
    }
  },
  
  methods: {
    handleInput(event) {
      this.$emit('input', event.target.value)
    }
  }
}
</script>

<style scoped>
.form-group {
  margin-bottom: 0;
}

.form-group.full-width {
  grid-column: 1 / -1;
}

.form-label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
  font-weight: 600;
  color: #374151;
  font-size: 12px;
}

.form-label i {
  color: #6b7280;
  font-size: 10px;
}

.form-control.compact {
  width: 100%;
  padding: 8px 12px;
  border: 2px solid #e5e7eb;
  border-radius: 6px;
  font-size: 13px;
  transition: all 0.2s ease;
  background: #fafafa;
  box-sizing: border-box;
  font-family: inherit;
  resize: vertical;
  min-height: 60px;
}

.form-control.compact:focus {
  outline: none;
  border-color: #667eea;
  background: white;
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
}

.form-control.compact:disabled {
  background-color: #f3f4f6;
  border-color: #d1d5db;
  color: #6b7280;
  cursor: not-allowed;
  resize: none;
}

.field-hint {
  margin-top: 4px;
  display: flex;
}

</style>