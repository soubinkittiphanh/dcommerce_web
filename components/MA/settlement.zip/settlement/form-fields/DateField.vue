<template>
  <div class="form-group">
    <label class="form-label required">
      <i class="fas fa-calendar"></i>
      ວັນທີລົງຊຳລະ
    </label>
    
    <v-menu
      ref="dateMenu"
      v-model="dateMenu"
      :close-on-content-click="false"
      transition="scale-transition"
      offset-y
      max-width="290px"
      min-width="auto"
      :disabled="disabled"
    >
      <template #activator="{ on, attrs }">
        <v-text-field
          :value="formattedDate"
          outlined
          dense
          clearable
          hide-details
          prepend-inner-icon="mdi-calendar"
          :error="!!error"
          :error-messages="error"
          :disabled="disabled"
          :class="{ 'compact-date-field': true }"
          v-bind="attrs"
          v-on="on"
          @click:clear="clearDate"
        />
      </template>
      <v-date-picker
        v-model="pickerDate"
        no-title
        :max="today"
        @input="setDate"
        :disabled="disabled"
      />
    </v-menu>
  </div>
</template>

<script>
export default {
  name: 'DateField',
  
  props: {
    value: {
      type: String,
      default: ''
    },
    error: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    max: {
      type: String,
      default: null
    }
  },
  
  data() {
    return {
      dateMenu: false,
      pickerDate: null
    }
  },
  
  computed: {
    formattedDate() {
      if (!this.value) return null
      return this.formatDateForDisplay(this.value)
    },
    
    today() {
      return this.max || new Date().toISOString().split('T')[0]
    }
  },
  
  watch: {
    value: {
      immediate: true,
      handler(newVal) {
        if (newVal) {
          this.pickerDate = newVal
        } else {
          this.pickerDate = null
        }
      }
    }
  },
  
  methods: {
    formatDateForDisplay(date) {
      if (!date) return null
      const d = new Date(date)
      const day = String(d.getDate()).padStart(2, '0')
      const month = String(d.getMonth() + 1).padStart(2, '0')
      const year = d.getFullYear()
      return `${day}/${month}/${year}`
    },
    
    setDate(val) {
      this.pickerDate = val
      this.$emit('input', val)
      this.$emit('change', val)
      this.dateMenu = false
    },
    
    clearDate() {
      this.pickerDate = null
      this.$emit('input', '')
      this.$emit('clear')
    }
  }
}
</script>

<style scoped>
.form-group {
  margin-bottom: 0;
}

.form-label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
  font-weight: 600;
  color: #374151;
  font-size: 12px;
}

.form-label.required::after {
  content: '*';
  color: #e74c3c;
  margin-left: 2px;
}

.form-label i {
  color: #6b7280;
  font-size: 10px;
}

/* Compact date field styles */
.compact-date-field {
  font-size: 13px !important;
}

.compact-date-field .v-input__control {
  min-height: 40px !important;
  max-height: 40px !important;
}

.compact-date-field .v-input__slot {
  padding: 0 12px !important;
  min-height: 40px !important;
  max-height: 40px !important;
  align-items: center !important;
}

.compact-date-field .v-text-field__details {
  display: none !important;
}

.compact-date-field .v-input__icon--prepend-inner {
  margin-top: 0 !important;
  margin-right: 8px !important;
  align-self: center !important;
}

.compact-date-field input {
  padding: 0 !important;
  margin: 0 !important;
  font-size: 13px !important;
  line-height: 1.2 !important;
  height: 38px !important;
}

.compact-date-field.v-text-field--outlined .v-input__control .v-input__slot {
  border: 2px solid #e5e7eb !important;
  border-radius: 6px !important;
  background: #fafafa !important;
}

.compact-date-field.v-input--is-focused .v-input__slot {
  border-color: #667eea !important;
  background: white !important;
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1) !important;
}

.compact-date-field.v-input--is-disabled .v-input__slot {
  background-color: #f3f4f6 !important;
  border-color: #d1d5db !important;
}

.compact-date-field .v-text-field--outlined fieldset {
  border: none !important;
}

.v-menu__content {
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12) !important;
  border-radius: 8px !important;
  overflow: hidden !important;
}

.v-date-picker {
  box-shadow: none !important;
}
</style>