<template>
  <div class="form-group">
    <label class="form-label required">
      <i class="fas fa-credit-card"></i>
      ວິທີການຊຳລະ
    </label>
    <div class="custom-select-wrapper">
      <select
        :value="value"
        class="form-control custom-select compact"
        :class="{ 'is-invalid': error }"
        :disabled="disabled"
        required
        @change="handleChange"
      >
        <option value="">ເລືອກວິທີການຊຳລະ</option>
        <option value="cash">ເງິນສົດ (Cash)</option>
        <option value="cheque">ເຊັກ (Cheque)</option>
        <option value="bank_transfer">ໂອນທະນາຄານ (Bank Transfer)</option>
        <option value="deduction">ຫັກລົບ (Deduction)</option>
      </select>
      <div class="select-icon">
        <i class="fas fa-chevron-down"></i>
      </div>
    </div>
    <div v-if="error" class="invalid-feedback">
      {{ error }}
    </div>
  </div>
</template>

<script>
export default {
  name: 'PaymentMethodField',
  
  props: {
    value: {
      type: String,
      default: ''
    },
    error: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  
  emits: ['input', 'change'],
  
  methods: {
    handleChange(event) {
      const newValue = event.target.value
      this.$emit('input', newValue)
      this.$emit('change', newValue)
    }
  }
}
</script>

<style scoped>
.form-group {
  margin-bottom: 0;
}

.form-label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
  font-weight: 600;
  color: #374151;
  font-size: 12px;
}

.form-label.required::after {
  content: '*';
  color: #e74c3c;
  margin-left: 2px;
}

.form-label i {
  color: #6b7280;
  font-size: 10px;
}

.custom-select-wrapper {
  position: relative;
}

.form-control.custom-select.compact {
  width: 100%;
  padding: 8px 30px 8px 12px;
  border: 2px solid #e5e7eb;
  border-radius: 6px;
  font-size: 13px;
  transition: all 0.2s ease;
  background: #fafafa;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}

.form-control.custom-select.compact:focus {
  outline: none;
  border-color: #667eea;
  background: white;
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
}

.form-control.custom-select.compact:disabled {
  background-color: #f3f4f6;
  border-color: #d1d5db;
  color: #6b7280;
  cursor: not-allowed;
}

.form-control.is-invalid {
  border-color: #e74c3c;
}

.select-icon {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
  color: #6b7280;
  font-size: 10px;
}

.invalid-feedback {
  display: block;
  color: #e74c3c;
  font-size: 10px;
  margin-top: 2px;
}
</style>