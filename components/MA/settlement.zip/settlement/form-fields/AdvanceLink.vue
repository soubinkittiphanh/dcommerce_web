<template>
  <div class="form-group full-width compact-advance">
    <div class="advance-toggle">
      <label class="form-label">
        <i class="fas fa-link"></i>
        ອ້າງອິງລາຍຈ່າຍລ່ວງໜ້າ
      </label>
      <div class="link-advance-options compact">
        <label class="radio-option">
          <input
            type="radio"
            :value="false"
            :checked="!isLinked"
            :disabled="disabled"
            @change="handleToggleLink(false)"
          />
          <span class="radio-label">ບໍ່ເຊື່ອມຕໍ່</span>
        </label>
        <label class="radio-option">
          <input
            type="radio"
            :value="true"
            :checked="isLinked"
            :disabled="disabled"
            @change="handleToggleLink(true)"
          />
          <span class="radio-label">ເຊື່ອມຕໍ່</span>
        </label>
      </div>
    </div>

    <div v-if="isLinked" class="advance-selection compact">
      <div class="advance-selection-container compact">
        <div class="custom-select-wrapper flex-1">
          <select
            :value="advanceId"
            class="form-control custom-select compact"
            :disabled="disabled"
            @change="handleAdvanceSelect($event.target.value)"
          >
            <option value="">ເລືອກລາຍຈ່າຍລ່ວງໜ້າ</option>
            <option
              v-for="advance in availableAdvances"
              :key="advance.id"
              :value="advance.id"
            >
              #{{ advance.id }} - {{ advance.receiveName }} - 
              {{ advance.ministry?.ministryName || '' }} - 
              {{ formatCurrency(advance.amount, advance.currency?.code) }}
            </option>
          </select>
          <div class="select-icon">
            <i class="fas fa-chevron-down"></i>
          </div>
        </div>
        <button
          type="button"
          class="btn btn-outline-primary btn-sm compact"
          @click.stop="$emit('browse')"
          :disabled="disabled || loading"
        >
          <i v-if="loading" class="fas fa-spinner fa-spin"></i>
          <i v-else class="fas fa-search"></i>
        </button>
      </div>

      <!-- Selected Advance Info -->
      <div v-if="selectedAdvance" class="advance-info compact">
        <div class="advance-summary">
          <span class="advance-id">#{{ selectedAdvance.id }}</span>
          <span class="advance-amount">
            {{ formatCurrency(selectedAdvance.amount, selectedAdvance.currency?.code) }}
          </span>
          <span class="advance-purpose">
            {{ selectedAdvance.purpose || 'No purpose' }}
          </span>
          <span :class="['status-badge', selectedAdvance.status]">
            {{ formatStatus(selectedAdvance.status) }}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AdvanceLink',
  
  props: {
    linkToAdvance: {
      type: [String, Boolean],
      default: false
    },
    advanceId: {
      type: [String, Number],
      default: ''
    },
    availableAdvances: {
      type: Array,
      default: () => []
    },
    disabled: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    }
  },
  
  computed: {
    isLinked() {
      return this.linkToAdvance === 'true' || this.linkToAdvance === true
    },
    
    selectedAdvance() {
      if (!this.advanceId) return null
      return this.availableAdvances.find(
        advance => advance.id == this.advanceId
      )
    }
  },
  
  mounted() {
    this.loadAdvances()
  },
  
  methods: {
    async loadAdvances() {
      this.$emit('load-advances')
    },
    
    handleToggleLink(value) {
      this.$emit('update:linkToAdvance', value ? 'true' : 'false')
      if (!value) {
        this.$emit('update:advanceId', '')
        this.$emit('clear')
      }
    },
    
    handleAdvanceSelect(value) {
      this.$emit('update:advanceId', value)
      this.$emit('select', value)
    },
    
    formatCurrency(amount, currency = 'LAK') {
      if (!amount && amount !== 0) return 'LAK 0'
      
      try {
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: currency || 'LAK',
          minimumFractionDigits: 0,
          maximumFractionDigits: 2
        }).format(amount)
      } catch (error) {
        return `${currency} ${amount.toLocaleString()}`
      }
    },
    
    formatStatus(status) {
      const statusLabels = {
        pending: 'ລໍຖ້າ',
        approved: 'ອະນຸມັດ',
        settled: 'ສຳເລັດ',
        cancelled: 'ຍົກເລີກ'
      }
      return statusLabels[status] || status
    }
  }
}
</script>

<style scoped>
.form-group.full-width {
  grid-column: 1 / -1;
}

.compact-advance {
  background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px;
  margin: 8px 0;
}

.advance-toggle {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.form-label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
  font-weight: 600;
  color: #374151;
  font-size: 12px;
}

.form-label i {
  color: #6b7280;
  font-size: 10px;
}

.link-advance-options.compact {
  display: flex;
  gap: 12px;
  margin-top: 4px;
}

.radio-option {
  display: flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  font-size: 12px;
  color: #374151;
}

.radio-option input[type='radio'] {
  margin: 0;
  transform: scale(0.8);
}

.radio-label {
  font-weight: 500;
}

.advance-selection.compact {
  margin-top: 8px;
}

.advance-selection-container.compact {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  margin-bottom: 8px;
}

.flex-1 {
  flex: 1;
}

.custom-select-wrapper {
  position: relative;
}

.form-control.custom-select.compact {
  width: 100%;
  padding: 8px 30px 8px 12px;
  border: 2px solid #e5e7eb;
  border-radius: 6px;
  font-size: 13px;
  transition: all 0.2s ease;
  background: #fafafa;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}

.form-control.custom-select.compact:focus {
  outline: none;
  border-color: #667eea;
  background: white;
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
}

.form-control.custom-select.compact:disabled {
  background-color: #f3f4f6;
  border-color: #d1d5db;
  color: #6b7280;
  cursor: not-allowed;
}

.select-icon {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
  color: #6b7280;
  font-size: 10px;
}

.btn.compact {
  padding: 6px 12px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  transition: all 0.2s ease;
  font-size: 12px;
}

.btn-sm.compact {
  padding: 8px 12px;
  font-size: 11px;
  min-height: 40px;
}

.btn-outline-primary {
  background: transparent;
  border: 2px solid #667eea;
  color: #667eea;
}

.btn-outline-primary:hover:not(:disabled) {
  background: #667eea;
  color: white;
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.advance-info.compact {
  margin-top: 8px;
  padding: 8px;
  background: #f0f9ff;
  border-radius: 6px;
  border: 1px solid #bae6fd;
}

.advance-summary {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  font-size: 11px;
}

.advance-id {
  font-weight: 700;
  color: #1e293b;
  font-family: 'Courier New', monospace;
  background: #e2e8f0;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 10px;
}

.advance-amount {
  font-weight: 700;
  color: #059669;
  background: #d1fae5;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 10px;
}

.advance-purpose {
  font-style: italic;
  color: #6b7280;
  font-size: 10px;
}

.status-badge {
  padding: 2px 6px;
  border-radius: 8px;
  font-size: 9px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.3px;
}

.status-badge.pending {
  background: #fef3c7;
  color: #92400e;
}

.status-badge.approved {
  background: #d1fae5;
  color: #065f46;
}

.status-badge.settled {
  background: #dbeafe;
  color: #1e40af;
}

</style>