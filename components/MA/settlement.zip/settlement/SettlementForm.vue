<template>
  <form @submit.prevent="handleSubmit" class="modal-body">
    <div v-if="loading || isSubmitting" class="form-loading">
      <div class="spinner-small"></div>
      <p>
        {{ isSubmitting ? 'ກຳລັງບັນທຶກຂໍ້ມູນ...' : 'ກຳລັງໂຫຼດຂໍ້ມູນ...' }}
      </p>
    </div>

    <div v-else class="form-grid compact">
      <!-- Row 1: Settlement Date -->
      <DateField
        v-model="formData.bookingDate"
        :error="errors.bookingDate"
        :disabled="isFormDisabled"
        @clear="clearFieldError('bookingDate')"
      />

      <!-- Row 2: Payment Method -->
      <PaymentMethodField
        v-model="formData.method"
        :error="errors.method"
        :disabled="isFormDisabled"
        @change="handleMethodChange"
      />

      <!-- Row 3: External Reference -->
      <div class="form-group">
        <label class="form-label">
          <i class="fas fa-hashtag"></i>
          ອີງຕາມ
        </label>
        <input
          v-model="formData.externalRef"
          type="text"
          class="form-control compact"
          :class="{ 'is-invalid': errors.externalRef }"
          :disabled="isFormDisabled"
          placeholder="ອີງຕາມ ການຕົກລົງ ເຫັນດີ..."
          maxlength="50"
        />
        <div v-if="errors.externalRef" class="invalid-feedback">
          {{ errors.externalRef }}
        </div>
      </div>

      <!-- Row 4: External Reference Number -->
      <div class="form-group">
        <label class="form-label">
          <i class="fas fa-hashtag"></i>
          ເລກອ້າງອິງພາຍນອກ
        </label>
        <input
          v-model="formData.externalRefNo"
          type="text"
          class="form-control compact"
          :class="{ 'is-invalid': errors.externalRefNo }"
          :disabled="isFormDisabled"
          placeholder="REF-001, TXN-123..."
          maxlength="50"
        />
        <div v-if="errors.externalRefNo" class="invalid-feedback">
          {{ errors.externalRefNo }}
        </div>
      </div>

      <!-- Row 5: Cheque Number (conditional) -->
      <div v-if="formData.method === 'cheque'" class="form-group">
        <label class="form-label required">
          <i class="fas fa-money-check"></i>
          ເລກເຊັກ
        </label>
        <input
          v-model="formData.chequeNo"
          type="text"
          class="form-control compact"
          :class="{ 'is-invalid': errors.chequeNo }"
          :disabled="isFormDisabled"
          placeholder="ໃສ່ເລກເຊັກ..."
          maxlength="20"
          :required="formData.method === 'cheque'"
        />
        <div v-if="errors.chequeNo" class="invalid-feedback">
          {{ errors.chequeNo }}
        </div>
      </div>

      <!-- Row 6: Currency -->
      <CurrencyField
        v-model="formData.currencyId"
        :currencies="currencies"
        :error="errors.currencyId"
        :disabled="isFormDisabled || isLinkedToAdvance"
        @change="updateSelectedCurrency"
      />

      <!-- Row 7: Amount -->
      <AmountField
        v-model="formData.amount"
        :currency-code="selectedCurrencyCode"
        :error="errors.amount"
        :disabled="isFormDisabled"
      />

      <!-- Row 8: From Person Name (conditional) -->
      <div v-if="formData.method === 'cash' || formData.method === 'cheque'" class="form-group">
        <label class="form-label" :class="{ required: formData.method === 'cash' || formData.method === 'cheque' }">
          <i class="fas fa-user-circle"></i>
          ຈາກທ່ານ (ຜູ້ຈ່າຍ)
        </label>
        <input
          v-model="formData.fromPersonName"
          type="text"
          class="form-control compact"
          :class="{ 'is-invalid': errors.fromPersonName }"
          :disabled="isFormDisabled"
          placeholder="ຊື່ຜູ້ຈ່າຍເງິນ..."
          maxlength="100"
          :required="formData.method === 'cash' || formData.method === 'cheque'"
        />
        <div v-if="errors.fromPersonName" class="invalid-feedback">
          {{ errors.fromPersonName }}
        </div>
      </div>

      <!-- Row 9: Ministry -->
      <div class="form-group">
        <label class="form-label">
          <i class="fas fa-building"></i>
          ສັງກັດຢູ່ (ກະຊວງ)
        </label>
        <div class="custom-select-wrapper">
          <select
            v-model="formData.ministryId"
            class="form-control custom-select compact"
            :class="{ 'is-invalid': errors.ministryId }"
            :disabled="isFormDisabled"
            @change="updateSelectedMinistry"
          >
            <option value="">ເລືອກກະຊວງ (ທາງເລືອກ)</option>
            <option v-for="ministry in ministries" :key="ministry.id" :value="ministry.id">
              {{ ministry.ministryCode }} - {{ ministry.ministryName }}
            </option>
          </select>
          <div class="select-icon">
            <i class="fas fa-chevron-down"></i>
          </div>
        </div>
      </div>

      <!-- Row 10: Bank Account (conditional) -->
      <BankAccountField
        v-if="formData.method === 'bank_transfer'"
        :value="formData.bankAccountId"
        :bank-accounts="filteredBankAccounts"
        :error="errors.bankAccountId"
        :disabled="isFormDisabled"
        @input="formData.bankAccountId = $event"
        @change="updateSelectedBankAccount"
      />

      <!-- Row 11: Exchange Rate -->
      <div class="form-group">
        <label class="form-label">
          <i class="fas fa-exchange-alt"></i>
          ອັດຕາແລກປ່ຽນ
        </label>
        <div class="input-group compact">
          <input
            v-model.number="formData.exchangeRate"
            type="number"
            step="0.0001"
            min="0"
            class="form-control compact"
            :class="{ 'is-invalid': errors.exchangeRate }"
            :disabled="isFormDisabled"
            placeholder="1.0000"
            @input="calculateEquivalentAmount"
          />
          <div class="input-group-append">
            <span class="input-group-text compact">
              <i class="fas fa-calculator"></i>
            </span>
          </div>
        </div>
        <div v-if="errors.exchangeRate" class="invalid-feedback">
          {{ errors.exchangeRate }}
        </div>
      </div>

      <!-- Row 12: Chart Account -->
      <div class="form-group">
        <label class="form-label">
          <i class="fas fa-chart-line"></i>
          ບັນຊີລວມ
        </label>
        <div class="custom-select-wrapper">
          <select
            v-model="formData.chartAccountId"
            class="form-control custom-select compact"
            :class="{ 'is-invalid': errors.chartAccountId }"
            :disabled="isFormDisabled"
          >
            <option value="">ເລືອກບັນຊີລວມ (ທາງເລືອກ)</option>
            <option v-for="chartAccount in chartAccounts" :key="chartAccount.id" :value="chartAccount.id">
              {{ chartAccount.accountNumber }} - {{ chartAccount.accountName }}
            </option>
          </select>
          <div class="select-icon">
            <i class="fas fa-chevron-down"></i>
          </div>
        </div>
      </div>

      <!-- Row 13: User/Proceeder -->
      <div class="form-group">
        <label class="form-label required">
          <i class="fas fa-user"></i>
          ຜູ້ລົງບັນຊີ (ຜູ້ຮັບ)
        </label>
        <div class="custom-select-wrapper">
          <select
            v-model="formData.userId"
            class="form-control custom-select compact"
            :class="{ 'is-invalid': errors.userId }"
            :disabled="true"
            required
          >
            <option value="">ເລືອກຜູ້ລົງບັນຊີ</option>
            <option v-for="user in users" :key="user.id" :value="user.id">
              {{ user.cus_name || user.name || user.username }}
            </option>
          </select>
          <div class="select-icon">
            <i class="fas fa-chevron-down"></i>
          </div>
        </div>
        <div v-if="errors.userId" class="invalid-feedback">
          {{ errors.userId }}
        </div>
      </div>

      <!-- Row 14: Money Advance Link -->
      <AdvanceLink
        :link-to-advance="formData.linkToAdvance"
        :advance-id="formData.moneyAdvanceId"
        :available-advances="availableAdvances"
        :disabled="isFormDisabled"
        :loading="loadingAdvances"
        @update:linkToAdvance="formData.linkToAdvance = $event"
        @update:advanceId="formData.moneyAdvanceId = $event"
        @browse="browseMoneyAdvances"
        @select="updateSelectedAdvance"
        @clear="clearAdvanceSelection"
        @load-advances="loadMoneyAdvances"
      />

      <!-- Row 15: Notes -->
      <NotesField
        v-model="formData.notes"
        :disabled="isFormDisabled"
      />
    </div>

    <!-- Form Validation Errors -->
    <FormValidationErrors
      v-if="formErrors.length > 0"
      :errors="formErrors"
    />

    <!-- Advance Browser Modal -->
    <AdvanceBrowser
      v-if="showAdvanceBrowser"
      :available-advances="availableAdvances"
      :loading="loadingAdvances"
      @select="confirmAdvanceSelection"
      @close="closeAdvanceBrowser"
    />
  </form>
</template>

<script>
// Import child components
import DateField from '../form-fields/DateField'
import PaymentMethodField from './form-fields/PaymentMethodField'
import CurrencyField from './form-fields/CurrencyField'
import AmountField from './form-fields/AmountField'
import BankAccountField from './form-fields/BankAccountField'
import AdvanceLink from './form-fields/AdvanceLink'
import NotesField from './form-fields/NotesField'
import FormValidationErrors from './FormValidationErrors'
import AdvanceBrowser from './AdvanceBrowser'

// Import composables
import { useSettlementForm } from '~/composables/useSettlementForm'
import { useSettlementValidation } from '~/composables/useSettlementValidation'
import { useMoneyAdvances } from '~/composables/useMoneyAdvances'

export default {
  name: 'SettlementForm',

  components: {
    DateField,
    PaymentMethodField,
    CurrencyField,
    AmountField,
    BankAccountField,
    AdvanceLink,
    NotesField,
    FormValidationErrors,
    AdvanceBrowser
  },

  props: {
    settlement: {
      type: Object,
      default: null
    },
    currencies: {
      type: Array,
      default: () => []
    },
    bankAccounts: {
      type: Array,
      default: () => []
    },
    ministries: {
      type: Array,
      default: () => []
    },
    chartAccounts: {
      type: Array,
      default: () => []
    },
    users: {
      type: Array,
      default: () => []
    },
    paymentMethod: {
      type: String,
      default: 'cash'
    },
    isSubmitting: {
      type: Boolean,
      default: false
    },
    isEditMode: {
      type: Boolean,
      default: false
    }
  },

  emits: ['update:formData', 'validation-change', 'submit'],

  data() {
    return {
      loading: false,
      loadingAdvances: false,
      showAdvanceBrowser: false,
      availableAdvances: [],
      formData: {},
      errors: {},
      formErrors: []
    }
  },

  computed: {
    isFormDisabled() {
      return this.loading || this.isSubmitting
    },

    isLinkedToAdvance() {
      return this.formData.linkToAdvance === 'true' && this.formData.moneyAdvanceId
    },

    selectedCurrency() {
      if (!this.formData.currencyId) return null
      return this.currencies.find(c => c.id == this.formData.currencyId)
    },

    selectedCurrencyCode() {
      if (!this.selectedCurrency) return 'LAK'
      return this.selectedCurrency.code || this.selectedCurrency.currencyCode || 'LAK'
    },

    selectedAdvance() {
      if (!this.formData.moneyAdvanceId) return null
      return this.availableAdvances.find(a => a.id == this.formData.moneyAdvanceId)
    },

    filteredBankAccounts() {
      const { getFilteredBankAccounts } = useSettlementForm()
      return getFilteredBankAccounts(this.bankAccounts, this.selectedCurrency)
    },

    user() {
      return this.$auth?.user || {}
    }
  },

  watch: {
    formData: {
      deep: true,
      handler(newData) {
        this.validateForm()
        this.$emit('update:formData', newData)
      }
    }
  },

  mounted() {
    this.initializeForm()
    this.loadMoneyAdvances()
  },

  methods: {
    async initializeForm() {
      const { initializeFormData } = useSettlementForm()
      
      this.loading = true
      try {
        this.formData = initializeFormData(
          this.settlement,
          this.paymentMethod,
          this.user
        )
        
        // Set default currency if none selected
        if (!this.formData.currencyId && this.currencies.length > 0) {
          const defaultCurrency = this.currencies.find(c => 
            (c.code || c.currencyCode) === 'LAK'
          ) || this.currencies[0]
          this.formData.currencyId = defaultCurrency.id
        }
      } finally {
        this.loading = false
      }
    },

    async loadMoneyAdvances() {
      const { loadMoneyAdvances } = useMoneyAdvances(this.$axios)
      
      this.loadingAdvances = true
      try {
        this.availableAdvances = await loadMoneyAdvances(this.formData.moneyAdvanceId)
      } finally {
        this.loadingAdvances = false
      }
    },

    validateForm() {
      const { validateForm, validateAdvanceLink } = useSettlementValidation()
      
      // Basic validation
      const { errors, formErrors, isValid } = validateForm(this.formData)
      
      // Additional advance validation if linked
      if (this.isLinkedToAdvance && this.selectedAdvance) {
        const advanceValidation = validateAdvanceLink(
          this.formData,
          this.selectedAdvance,
          () => this.getAdvanceCurrency()
        )
        
        Object.assign(errors, advanceValidation.errors)
        formErrors.push(...advanceValidation.formErrors)
      }
      
      this.errors = errors
      this.formErrors = formErrors
      
      this.$emit('validation-change', { 
        isValid: isValid && formErrors.length === 0, 
        errors 
      })
    },

    handleSubmit() {
      if (this.validateForm()) {
        this.$emit('submit', this.formData)
      }
    },

    handleMethodChange() {
      const { handleMethodChange } = useSettlementForm()
      this.formData = handleMethodChange(this.formData, this.formData.method)
      this.clearFieldError('method')
    },

    updateSelectedCurrency() {
      const { handleCurrencyChange } = useSettlementForm()
      this.formData = handleCurrencyChange(
        this.formData,
        this.currencies,
        this.isEditMode
      )
      this.clearFieldError('currencyId')
    },

    updateSelectedBankAccount() {
      this.clearFieldError('bankAccountId')
    },

    updateSelectedMinistry() {
      // Any additional logic for ministry change
    },

    updateSelectedAdvance() {
      const { syncCurrencyFromAdvance, syncAmountFromAdvance } = useSettlementForm()
      
      if (this.selectedAdvance) {
        this.formData = syncCurrencyFromAdvance(
          this.formData,
          this.selectedAdvance,
          this.currencies
        )
        this.formData = syncAmountFromAdvance(this.formData, this.selectedAdvance)
      }
    },

    clearAdvanceSelection() {
      this.formData.moneyAdvanceId = ''
      this.formData.linkToAdvance = 'false'
      
      // Reset to default currency
      if (this.currencies.length > 0) {
        const defaultCurrency = this.currencies.find(c => 
          (c.code || c.currencyCode) === 'LAK'
        ) || this.currencies[0]
        this.formData.currencyId = defaultCurrency.id
        this.formData.exchangeRate = 1
      }
      
      this.formData.amount = null
    },

    browseMoneyAdvances() {
      this.showAdvanceBrowser = true
    },

    closeAdvanceBrowser() {
      this.showAdvanceBrowser = false
    },

    confirmAdvanceSelection(advance) {
      this.formData.moneyAdvanceId = advance.id
      this.updateSelectedAdvance()
      this.closeAdvanceBrowser()
    },

    calculateEquivalentAmount() {
      // Trigger any equivalent amount calculations
    },

    clearFieldError(fieldName) {
      if (this.errors[fieldName]) {
        this.$delete(this.errors, fieldName)
      }
    },

    getAdvanceCurrency() {
      const { getAdvanceCurrency } = useMoneyAdvances(this.$axios)
      return getAdvanceCurrency(this.selectedAdvance, this.currencies)
    }
  }
}
</script>

<style scoped>
.modal-body {
  padding: 16px 24px;
  flex: 1;
  overflow-y: auto;
  min-height: 0;
}

.form-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #666;
}

.spinner-small {
  width: 20px;
  height: 20px;
  border: 2px solid #f3f3f3;
  border-top: 2px solid #3498db;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-right: 10px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.form-grid.compact {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  height: 100%;
  align-content: start;
}

.form-group {
  margin-bottom: 0;
}

.form-label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
  font-weight: 600;
  color: #374151;
  font-size: 12px;
}

.form-label.required::after {
  content: '*';
  color: #e74c3c;
  margin-left: 2px;
}

.form-label i {
  color: #6b7280;
  font-size: 10px;
}

.form-control.compact {
  width: 100%;
  padding: 8px 12px;
  border: 2px solid #e5e7eb;
  border-radius: 6px;
  font-size: 13px;
  transition: all 0.2s ease;
  background: #fafafa;
  box-sizing: border-box;
}

.form-control.compact:focus {
  outline: none;
  border-color: #667eea;
  background: white;
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
}

.form-control.compact:disabled {
  background-color: #f3f4f6;
  border-color: #d1d5db;
  color: #6b7280;
  cursor: not-allowed;
}

.form-control.is-invalid {
  border-color: #e74c3c;
}

.invalid-feedback {
  display: block;
  color: #e74c3c;
  font-size: 10px;
  margin-top: 2px;
}

.custom-select-wrapper {
  position: relative;
}

.custom-select.compact {
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  padding-right: 30px;
}

.select-icon {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
  color: #6b7280;
  font-size: 10px;
}

.input-group.compact {
  display: flex;
  border-radius: 6px;
  overflow: hidden;
}

.input-group.compact .form-control {
  border-radius: 6px 0 0 6px;
  border-right: none;
}

.input-group-append {
  display: flex;
}

.input-group-text.compact {
  background: #f8f9fa;
  border: 2px solid #e5e7eb;
  border-left: none;
  border-radius: 0 6px 6px 0;
  padding: 8px 12px;
  font-weight: 600;
  color: #6b7280;
  font-size: 12px;
}

@media (max-width: 1200px) {
  .form-grid.compact {
    grid-template-columns: repeat(3, 1fr);
  }
}

@media (max-width: 768px) {
  .form-grid.compact {
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }
}

@media (max-width: 480px) {
  .form-grid.compact {
    grid-template-columns: 1fr;
  }
}
</style>