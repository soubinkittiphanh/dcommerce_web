<template>
  <div class="modal-overlay browser-overlay" @click="handleOverlayClick">
    <div class="modal-dialog advance-browser-dialog" @click.stop>
      <div class="modal-header">
        <div class="modal-title-section">
          <i class="fas fa-search modal-icon"></i>
          <h5 class="modal-title">ເລືອກລາຍຈ່າຍລ່ວງໜ້າ</h5>
        </div>
        <button @click="$emit('close')" class="close-btn">
          <i class="fas fa-times"></i>
        </button>
      </div>

      <div class="modal-body">
        <!-- Search and Filters -->
        <div class="advance-filters compact">
          <div class="filter-row compact">
            <div class="filter-group">
              <input
                v-model="searchQuery"
                type="text"
                class="form-control compact"
                placeholder="ຄົ້ນຫາຕາມຈຸດປະສົງ, ໝາຍເຫດ..."
                @input="filterAdvances"
              />
            </div>
            <div class="filter-group">
              <select
                v-model="statusFilter"
                class="form-control compact"
                @change="filterAdvances"
              >
                <option value="">ທຸກສະຖານະ</option>
                <option value="pending">ລໍຖ້າ</option>
                <option value="approved">ອະນຸມັດ</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Advances List -->
        <div class="advances-list compact">
          <div v-if="loading" class="loading-state">
            <div class="spinner-small"></div>
            <p>ກຳລັງໂຫຼດ...</p>
          </div>

          <div v-else-if="filteredList.length === 0" class="empty-state">
            <i class="fas fa-inbox"></i>
            <p>ບໍ່ພົບລາຍຈ່າຍລ່ວງໜ້າ</p>
          </div>

          <div v-else class="advance-items compact">
            <div
              v-for="advance in filteredList"
              :key="advance.id"
              class="advance-item compact"
              :class="{ selected: selectedAdvance?.id === advance.id }"
              @click="selectAdvance(advance)"
            >
              <div class="advance-item-content compact">
                <div class="advance-item-header compact">
                  <span class="advance-id">#{{ advance.id }}</span>
                  <span :class="['status-badge', advance.status]">
                    {{ formatStatus(advance.status) }}
                  </span>
                </div>
                <div class="advance-item-body compact">
                  <div class="advance-amount">
                    {{ formatCurrency(advance.amount, advance.currency?.code) }}
                  </div>
                  <div class="advance-date">
                    {{ formatDate(advance.bookingDate) }}
                  </div>
                  <div v-if="advance.purpose" class="advance-purpose">
                    {{ advance.purpose }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer compact">
        <button
          type="button"
          @click="$emit('close')"
          class="btn btn-secondary compact"
        >
          <i class="fas fa-times"></i>
          ຍົກເລີກ
        </button>
        <button
          type="button"
          @click="confirmSelection"
          class="btn btn-primary compact"
          :disabled="!selectedAdvance"
        >
          <i class="fas fa-check"></i>
          ເລືອກ
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AdvanceBrowser',
  
  props: {
    availableAdvances: {
      type: Array,
      default: () => []
    },
    loading: {
      type: Boolean,
      default: false
    }
  },
  
  emits: ['select', 'close'],
  
  data() {
    return {
      searchQuery: '',
      statusFilter: '',
      selectedAdvance: null,
      filteredList: []
    }
  },
  
  mounted() {
    this.filteredList = [...this.availableAdvances]
    document.body.style.overflow = 'hidden'
  },
  
  beforeDestroy() {
    document.body.style.overflow = 'auto'
  },
  
  watch: {
    availableAdvances: {
      immediate: true,
      handler(advances) {
        this.filterAdvances()
      }
    }
  },
  
  methods: {
    filterAdvances() {
      let filtered = [...this.availableAdvances]
      
      if (this.statusFilter) {
        filtered = filtered.filter(
          advance => advance.status === this.statusFilter
        )
      }
      
      if (this.searchQuery) {
        const query = this.searchQuery.toLowerCase()
        filtered = filtered.filter(advance =>
          (advance.purpose && advance.purpose.toLowerCase().includes(query)) ||
          (advance.note && advance.note.toLowerCase().includes(query)) ||
          advance.id.toString().includes(query)
        )
      }
      
      this.filteredList = filtered
    },
    
    selectAdvance(advance) {
      this.selectedAdvance = advance
    },
    
    confirmSelection() {
      if (this.selectedAdvance) {
        this.$emit('select', this.selectedAdvance)
        this.$emit('close')
      }
    },
    
    handleOverlayClick(event) {
      if (event.target === event.currentTarget) {
        this.$emit('close')
      }
    },
    
    formatCurrency(amount, currency = 'LAK') {
      if (!amount && amount !== 0) return 'LAK 0'
      
      try {
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: currency || 'LAK',
          minimumFractionDigits: 0,
          maximumFractionDigits: 2
        }).format(amount)
      } catch (error) {
        return `${currency} ${amount.toLocaleString()}`
      }
    },
    
    formatDate(date) {
      if (!date) return 'ບໍ່ລະບຸ'
      return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    },
    
    formatStatus(status) {
      const statusLabels = {
        pending: 'ລໍຖ້າ',
        approved: 'ອະນຸມັດ',
        settled: 'ສຳເລັດ',
        cancelled: 'ຍົກເລີກ'
      }
      return statusLabels[status] || status
    }
  }
}
</script>

<style scoped>
.browser-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1100;
  backdrop-filter: blur(4px);
}

.advance-browser-dialog {
  background: white;
  border-radius: 12px;
  width: 600px;
  max-width: 90vw;
  max-height: 80vh;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  display: flex;
  flex-direction: column;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  border-bottom: 1px solid #e9ecef;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.modal-title-section {
  display: flex;
  align-items: center;
  gap: 12px;
}

.modal-icon {
  font-size: 18px;
  opacity: 0.9;
}

.modal-title {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
}

.close-btn {
  background: none;
  border: none;
  font-size: 16px;
  cursor: pointer;
  color: white;
  opacity: 0.8;
  transition: opacity 0.2s;
  padding: 6px;
  border-radius: 4px;
}

.close-btn:hover {
  opacity: 1;
  background: rgba(255, 255, 255, 0.1);
}

.modal-body {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.advance-filters.compact {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px;
  margin-bottom: 12px;
}

.filter-row.compact {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 12px;
  align-items: center;
}

.form-control.compact {
  padding: 8px 12px;
  border: 2px solid #e5e7eb;
  border-radius: 6px;
  font-size: 13px;
  transition: all 0.2s ease;
  background: #fafafa;
}

.form-control.compact:focus {
  outline: none;
  border-color: #667eea;
  background: white;
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
}

.advances-list.compact {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  max-height: 400px;
  overflow-y: auto;
}

.advance-items.compact {
  padding: 8px;
}

.advance-item.compact {
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  margin-bottom: 8px;
  padding: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.advance-item.compact:hover {
  background: #f0f9ff;
  border-color: #60a5fa;
}

.advance-item.compact.selected {
  background: #dbeafe;
  border-color: #3b82f6;
}

.advance-item-content.compact {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.advance-item-header.compact {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.advance-item-body.compact {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 8px;
  font-size: 11px;
}

.advance-id {
  font-weight: 700;
  color: #1e293b;
  font-family: 'Courier New', monospace;
  background: #e2e8f0;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 10px;
}

.advance-amount {
  font-weight: 700;
  color: #059669;
  font-size: 12px;
}

.advance-date {
  color: #6b7280;
  font-size: 11px;
}

.advance-purpose {
  font-style: italic;
  color: #6b7280;
  font-size: 10px;
  grid-column: 1 / -1;
}

.status-badge {
  padding: 2px 6px;
  border-radius: 8px;
  font-size: 9px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.3px;
}

.status-badge.pending {
  background: #fef3c7;
  color: #92400e;
}

.status-badge.approved {
  background: #d1fae5;
  color: #065f46;
}

.loading-state,
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #666;
}

.empty-state i {
  font-size: 48px;
  color: #ccc;
  margin-bottom: 16px;
}

.spinner-small {
  width: 20px;
  height: 20px;
  border: 2px solid #f3f3f3;
  border-top: 2px solid #3498db;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-right: 10px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.modal-footer.compact {
  padding: 12px 24px;
  border-top: 1px solid #e9ecef;
  background: #f8f9fa;
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.btn {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s ease;
  font-size: 13px;
}

.btn.compact {
  padding: 8px 14px;
  font-size: 12px;
}

.btn:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.btn-primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-secondary {
  background: #6c757d;
  color: white;
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
</style>