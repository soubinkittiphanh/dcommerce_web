<template>
  <div v-if="errors && errors.length > 0" class="form-errors compact">
    <h6>
      <i class="fas fa-exclamation-circle"></i>
      ກະລຸນາແກ້ໄຂຂໍ້ຜິດພາດ:
    </h6>
    <ul>
      <li v-for="(error, index) in errors" :key="index">
        {{ error }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'FormValidationErrors',
  
  props: {
    errors: {
      type: Array,
      default: () => []
    }
  }
}
</script>

<style scoped>
.form-errors.compact {
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: 6px;
  padding: 12px;
  margin-top: 12px;
}

.form-errors.compact h6 {
  margin: 0 0 6px 0;
  color: #dc2626;
  font-size: 12px;
  display: flex;
  align-items: center;
  gap: 4px;
  font-weight: 600;
}

.form-errors.compact ul {
  margin: 0;
  padding-left: 16px;
  color: #dc2626;
  font-size: 11px;
  list-style-type: disc;
}

.form-errors.compact ul li {
  margin-bottom: 2px;
}
</style>